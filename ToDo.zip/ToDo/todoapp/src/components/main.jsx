import "../index.css";
import Button from 'react-bootstrap/Button';
import Plus from "../images/ic--round-plus.svg";
import Circle from "../images/material-symbols--circle-outline.svg";
import { useEffect, useState } from "react";
import { useCookies } from 'react-cookie';
import DeleteIcon from "../ic--baseline-delete.svg";

const Main = () => {
    const [task, setTask] = useState("");
    const [value, setValue] = useState(0);
    const [tasks, setTasks] = useState([]);
    const [cookies, setCookie] = useCookies(['todoLists']);

    useEffect(() => {
        if (cookies.todoLists) {
            setTasks(cookies.todoLists);
        }
    }, [cookies]);

    const addTask = () => {
        if (task) {
            const newTasks = [...tasks, { critic: value, task: task }];
            setTasks(newTasks);
            setTask("");
            setCookie('todoLists', newTasks, { path: '/' });
        }
    };

    const deleteTask = (indexToDelete) => {
        const newTasks = tasks.filter((_, index) => index !== indexToDelete);
        setTasks(newTasks);
        setCookie('todoLists', newTasks, { path: '/' });
    };

    const handleEnterPress = (event) => {
        if (event.key === 'Enter') {
            addTask();
        }
    };

    useEffect(() => {
        console.log(tasks);
    }, [tasks]);

    return (
        <>
            <div className="d-flex justify-content-center align-items-center h-screen bg-gray-200">
                <div className="bg-white p-8 rounded-4 shadow-lg d-flex flex-column align-items-center">
                    <h2 className="mb-4">Seku To Do App</h2>
                    <div className="d-flex align-items-center">
                        <input
                            type="text"
                            placeholder="Görev ekleyin"
                            value={task}
                            onKeyDown={handleEnterPress}
                            onChange={(e) => setTask(e.target.value)}
                            className="border rounded-2 px-2 w-[300px] py-2"
                        />
                        <Button variant="primary" className="ms-2 py-1 px-2">
                            <img src={Plus} alt="" onClick={addTask} className="w-[30px]" />
                        </Button>
                    </div>
                    <p className="my-1 mt-3">Önem derecesi</p>
                    <div className="d-flex align-items-center gap-2 mb-2">
                        <Button variant="secondary" onClick={() => setValue(0)}><img src={Circle} alt="" className="w-[30px]" /></Button>
                        <Button variant="success" onClick={() => setValue(1)} className="d-flex justify-content-center align-items-center h-[45px] w-[50px]"><span className="fs-3 fw-semibold">!</span></Button>
                        <Button variant="warning" onClick={() => setValue(2)} className="d-flex justify-content-center align-items-center h-[45px] w-[50px]"><span className="fs-3 fw-semibold">!!</span></Button>
                        <Button variant="danger" onClick={() => setValue(3)} className="d-flex justify-content-center align-items-center h-[45px] w-[50px]"><span className="fs-3 fw-semibold">!!!</span></Button>
                    </div>
                    <hr className="w-100" />
                    <div className="d-flex align-items-center">
                        <ul className="p-0">
                            {tasks.map((listTasks, index) => (
                                <li key={index}>
                                    <div className="d-flex align-items-center justify-content-between px-2 w-[700px]">
                                        <span className="fs-5 fw-semibold">{listTasks.task}</span>
                                        <span className="fs-3 fw-semibold text-danger d-flex align-items-center">
                                            {listTasks.critic === 3 ? "!!!" : listTasks.critic === 2 ? "!!" : listTasks.critic === 1 ? "!" : "O"}
                                            <span className="d-flex">
                                                | <img src={DeleteIcon} onClick={() => deleteTask(index)} className="w-[30px] cursor-pointer" alt="Delete" />
                                            </span>
                                        </span>
                                    </div>
                                </li>
                            ))}
                        </ul>
                    </div>
                </div>
            </div>
        </>
    );
}

export default Main;
