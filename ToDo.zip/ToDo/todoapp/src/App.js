import "./index.css" 
import 'bootstrap/dist/css/bootstrap.min.css';
import Main from "./components/main"

function App() {
  return (
    <>
      <Main />
    </>
  );
}

export default App;
